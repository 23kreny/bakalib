# Bakaláři Python Library
A library for accessing 'Bakaláři' school system easily.